﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PetStore.Common
{
    public class DbConfiguration
    {
        public static string DefConnectionString =
            @"Server=(localdb)\MSSQLLocalDB;Database=PetStore;Integrated security=true";
    }
}
